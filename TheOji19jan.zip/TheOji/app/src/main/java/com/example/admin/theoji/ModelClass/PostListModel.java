package com.example.admin.theoji.ModelClass;

import java.io.Serializable;

public class PostListModel implements Serializable {

    private String name;
    private String email;
    private String content;
    private String userimg;
    private String postimg;
    private String date;

    public PostListModel(String name, String email, String content, String postimg, String userimg, String date) {
        this.name = name;
        this.email = email;
        this.content=content;

        this.postimg=postimg;
        this.userimg = userimg;
        this.date = date;

    }


    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }

    public String getUserimg() {
        return userimg;
    }

    public String getPostimg() {
        return postimg;
    }

    public void setPostimg(String postimg) {
        this.postimg = postimg;
    }

    public void setUserimg(String userimg) {

        this.userimg = userimg;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}
