package com.example.admin.theoji;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class LibraryActivity extends AppCompatActivity {
    ImageView viewlibrary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        viewlibrary = (ImageView)findViewById(R.id.viewlibrary);

        viewlibrary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LibraryActivity.this,AddLibraryActivity.class);
                startActivity(intent);

            }
        });
    }
}
