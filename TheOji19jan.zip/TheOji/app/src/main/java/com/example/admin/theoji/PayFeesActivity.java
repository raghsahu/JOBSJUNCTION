package com.example.admin.theoji;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class PayFeesActivity  extends AppCompatActivity {
    ImageView viewpayfees;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_fees);

        viewpayfees = (ImageView)findViewById(R.id.viewpayfees);

        viewpayfees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PayFeesActivity.this,PayAddFeesActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
