package com.example.admin.theoji.Adapter;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.admin.theoji.ModelClass.PostListModel;
import com.example.admin.theoji.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    private static final String TAG = "PostAdapter";
    private ArrayList<PostListModel> PostList;
    public Context context;

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView img_person,img2;
        public TextView txt1, txt2, txt3,txt_nm;
        public LinearLayout btn1,btn2,btn3,lin_vew;
        CardView cardeview;
        int pos;
        public ViewHolder(View view) {
            super(view);
            img_person = (ImageView)view.findViewById(R.id.img_person);
            img2 = (ImageView)view.findViewById(R.id.img2);
            txt1 = (TextView) view.findViewById(R.id.txt1);
            txt2 = (TextView) view.findViewById(R.id.txt2);
            txt3 = (TextView) view.findViewById(R.id.txt3);
//            txt4 = (TextView) view.findViewById(R.id.txt4);
            txt_nm = (TextView) view.findViewById(R.id.txt_nm);

            btn1 = (LinearLayout) view.findViewById(R.id.btn1);
            btn2 = (LinearLayout) view.findViewById(R.id.btn2);
            btn3 = (LinearLayout) view.findViewById(R.id.btn3);
//            lin_vew = (LinearLayout)view.findViewById(R.id.lin_vew);
            cardeview = (CardView)view.findViewById(R.id.cardeview);
        }
    }

    public static Context mContext;
    public PostAdapter(Context mContext, ArrayList<PostListModel> post_list) {
        context = mContext;
        PostList = post_list;
    }

        @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.post_items, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, int position) {
        final PostListModel postListModel = PostList.get(position);

        viewHolder.txt1.setText(postListModel.getName());
        viewHolder.txt2.setText(postListModel.getEmail());
        viewHolder.txt3.setText(postListModel.getDate());
        viewHolder.txt_nm.setText(postListModel.getContent());
        Picasso.get().load("http://theoji.com/uploads/apex_school.jpg").into(viewHolder.img2);
//        Picasso.get().load("http://theoji.com//assets/team/"+postListModel.getUserimg()).into(viewHolder.img_person);

//        Glide.with(mContext).load("http://theoji.com/uploads/"+postListModel.getPostimg())
//                .thumbnail(0.5f)
//                .into(viewHolder.img2);
//
//        Glide.with(mContext).load("http://theoji.com//assets/team/"+postListModel.getUserimg())
//                .thumbnail(0.5f)
//                .into(viewHolder.img_person);

//.placeholder(R.drawable.placeholder)
        //.diskCacheStrategy(DiskCacheStrategy.ALL)


        viewHolder.cardeview.setTag(viewHolder);
        viewHolder.btn1.setTag(viewHolder);
        viewHolder.btn2.setTag(viewHolder);
        viewHolder.btn3.setTag(viewHolder);
        viewHolder.pos = position;

        viewHolder.btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        viewHolder.btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        viewHolder.btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return PostList.size();
    }
}
