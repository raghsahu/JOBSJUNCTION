package com.example.admin.theoji;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class AddHomeWork extends AppCompatActivity {
    Spinner spin_class;
    private ArrayAdapter<String> classAdapter;
    private ArrayList<String> classList;
    String Class;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_home_work);

        spin_class = (Spinner)findViewById(R.id.spin_class);

        classList = new ArrayList<>();
        classList.add("Select Class");
        classList.add("Nursery");
        classList.add("KG1");
        classList.add("KG2");
        classList.add("1");
        classList.add("2");
        classList.add("3");
        classList.add("4");
        classList.add("5");
        classList.add("6");
        classList.add("7");
        classList.add("8");
        classList.add("9");
        classList.add("10");
        classList.add("11 Mathes");
        classList.add("11 Bio");
        classList.add("11 Commerce");

        spin_class.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Class = classAdapter.getItem(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        classAdapter = new ArrayAdapter<String>(AddHomeWork.this, R.layout.spinner_row, classList);
        classAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_class.setAdapter(classAdapter);

    }
}
