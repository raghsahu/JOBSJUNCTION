package com.example.admin.theoji;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class TeacherActivity extends AppCompatActivity {
    ImageView viewTeacher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);

        viewTeacher = (ImageView)findViewById(R.id.viewTeacher);

        viewTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TeacherActivity.this,AddTeacher.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
