package com.example.admin.theoji;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class FirstStepActivity extends Fragment {

    Button cont_reg;
    RadioButton Male, Female;
    RadioGroup sex;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View firstView = inflater.inflate(R.layout.activity_firststep , container , false);

//        return super.onCreateView(inflater, container, savedInstanceState);

        cont_reg=(Button)firstView.findViewById(R.id.cont_reg);

        sex=(RadioGroup)firstView.findViewById(R.id.sex);
        Male=(RadioButton)firstView.findViewById(R.id.male);
        Female=(RadioButton)firstView.findViewById(R.id.female);

        Male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Female.setChecked(false);

            }
        });
        Female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Male.setChecked(false);

            }
        });

        cont_reg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
//                getFragmentManager()
//                        .beginTransaction()
//                        .replace(R.id.pager, new SeconStepActivity())
//                        .commit();

                Fragment seconFragment = new SeconStepActivity();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.pager, seconFragment);
                transaction.addToBackStack(null);
                transaction.commit();

            }
        });

        return firstView;

}

}
