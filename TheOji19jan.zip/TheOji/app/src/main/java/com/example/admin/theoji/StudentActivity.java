package com.example.admin.theoji;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

public class StudentActivity extends AppCompatActivity {
    ImageView viewStudent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        viewStudent = (ImageView)findViewById(R.id.viewstudent);

        viewStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StudentActivity.this,AddStudentActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

