package com.example.admin.theoji.Adapter;

import android.content.Context;
import android.support.v7.widget.CardView;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.admin.theoji.ModelClass.NewsEventModel;
import com.example.admin.theoji.R;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class NewsEventsAdapter extends RecyclerView.Adapter<NewsEventsAdapter.ViewHolder> {

    private static final String TAG = "NewsEventsAdapter";
    private ArrayList<NewsEventModel> NewsEventsList;
    public Context context;
    String resId = "";

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView newsName, newsEmail,newsTittle, newsContent, newsDate;
        public ImageView profileImg, newsImg;
        public LinearLayout btn1,btn2, btn3;
        CardView cardeview;
        int pos;

        public ViewHolder(View view) {
            super(view);

            newsName = (TextView)view.findViewById(R.id.txtname);
            newsEmail = (TextView)view.findViewById(R.id.txt2);
            newsContent = (TextView)view.findViewById(R.id.news_description);
//            newsTime = (TextView)view.findViewById(R.id.time);
            newsTittle = (TextView)view.findViewById(R.id.title_news);
            newsDate = (TextView)view.findViewById(R.id.date);
            profileImg=(ImageView)view.findViewById(R.id.img_person);
            newsImg=(ImageView)view.findViewById(R.id.iv_news);
            btn1 = (LinearLayout) view.findViewById(R.id.btn1);
            btn2 = (LinearLayout) view.findViewById(R.id.btn2);
            btn3 = (LinearLayout) view.findViewById(R.id.btn3);

            cardeview = (CardView)view.findViewById(R.id.cardeview);
        }
    }

    public static Context mContext;

    public NewsEventsAdapter(Context mContext, ArrayList<NewsEventModel> news_list) {
        context = mContext;
        NewsEventsList = news_list;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.news_post_item, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        final NewsEventModel newsEventModel = NewsEventsList.get(position);

//        Log.d( "position::: " , String.valueOf(NewsEventsList.size()));

        viewHolder.newsEmail.setText(newsEventModel.getEmail());
        viewHolder.newsTittle.setText(newsEventModel.getTitle());
        viewHolder.newsContent.setText(newsEventModel.getContent());
        viewHolder.newsName.setText(newsEventModel.getName());
        viewHolder.newsDate.setText(newsEventModel.getDate());
        Picasso.get().load("http://theoji.com/uploads/"+newsEventModel.getPostimg()).into(viewHolder.newsImg);
        Picasso.get().load("http://theoji.com//assets/team/"+newsEventModel.getUserimg()).into(viewHolder.profileImg);

//        Glide.with(mContext).load("http://theoji.com/uploads/"+postListModel.getPostimg())
//                .thumbnail(0.5f)
//                .into(viewHolder.img2);
//
//        Glide.with(mContext).load("http://theoji.com//assets/team/"+postListModel.getUserimg())
//                .thumbnail(0.5f)
//                .into(viewHolder.img_person);

//        viewHolder.newsImg.setImageResource(R.drawable.m1);
//        viewHolder.profileImg.setImageResource(R.drawable.m1);
//
//        new NewsActivity.DownloadImageTask(viewHolder.newsImg).execute(NewsEventsList.get(position).getUserimg());
//        new NewsActivity.DownloadImageTask(viewHolder.profileImg).execute(NewsEventsList.get(position).getPostimg());


        viewHolder.cardeview.setTag(viewHolder);
        viewHolder.pos = position;

        viewHolder.btn1.setTag(viewHolder);
        viewHolder.btn2.setTag(viewHolder);

        viewHolder.btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        viewHolder.btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        viewHolder.btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return NewsEventsList.size();
    }

    private String convertTime(String time) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
        java.util.Date date = null;

        try {
            date = format.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String convertedDate = format1.format(date);

        return convertedDate;
    }




}