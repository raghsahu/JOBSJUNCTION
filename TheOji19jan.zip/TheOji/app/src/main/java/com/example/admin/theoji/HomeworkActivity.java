package com.example.admin.theoji;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class HomeworkActivity extends AppCompatActivity {
    ImageView viewhomeWork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework);

        viewhomeWork = (ImageView)findViewById(R.id.viewhomeWork);

        viewhomeWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeworkActivity.this,AddHomeWork.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

