package com.example.admin.theoji;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class SeconStepActivity extends Fragment {

    Spinner rteType;
    Spinner country;
    Spinner state;
    private ArrayAdapter<String> rteTypeAdapter;
    private ArrayList<String> rteTypeList;

    private ArrayAdapter<String> countryAdapter;
    private ArrayList<String> countryList;

    private ArrayAdapter<String> stateAdapter;
    private ArrayList<String> stateList;

    String RTEType;
    String Country;
    String State;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View secondView = inflater.inflate(R.layout.activity_secondstep , container , false);

        country = (Spinner)secondView.findViewById(R.id.country);
        rteType = (Spinner)secondView.findViewById(R.id.RTEtype);
        state = (Spinner)secondView.findViewById(R.id.state);

//RTE type spinner list
        rteTypeList = new ArrayList<>();
        rteTypeList.add("yes");
        rteTypeList.add("no");

        rteType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                RTEType = rteTypeAdapter.getItem(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        rteTypeAdapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_row, rteTypeList);
        rteTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rteType.setAdapter(rteTypeAdapter);

// country spinner list
       countryList = new ArrayList<>();
        countryList.add("India");

        country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Country = countryAdapter.getItem(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        countryAdapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_row, countryList);
        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        country.setAdapter(countryAdapter);

        //state spinner list
        stateList = new ArrayList<>();
        stateList.add("Select State");

        state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                State =stateAdapter.getItem(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        stateAdapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_row, stateList);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        state.setAdapter(stateAdapter);



        return secondView;
    }

}
